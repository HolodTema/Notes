package com.example.notes01;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    TextView textCountNotes;
    DatabaseHelper databaseHelper;
    SQLiteDatabase db;
    Cursor noteCursor;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = findViewById(R.id.list);
        textCountNotes = findViewById(R.id.textCountNotes);

        databaseHelper = new DatabaseHelper(getApplicationContext());
    }

    @Override
    protected void onResume() {
        super.onResume();
        db = databaseHelper.getReadableDatabase();
        noteCursor = db.rawQuery("select * from "+DatabaseHelper.TABLE, null);
        if (noteCursor.moveToFirst()) {
            ArrayList<NoteListElement> noteList = new ArrayList();
            do{
                noteList.add(new NoteListElement(noteCursor.getInt(0),noteCursor.getString(1), noteCursor.getString(2), noteCursor.getString(3)));
            }
            while (noteCursor.moveToNext());
            NoteAdapter noteAdapter = new NoteAdapter(this, R.layout.three_list_item, noteList);
            listView.setAdapter(noteAdapter);
            AdapterView.OnItemClickListener itemListener = new AdapterView.OnItemClickListener() {
                @Override
                public void onItemClick(AdapterView<?> parent, View v, int position, long id) {
                    NoteListElement clickedNote = (NoteListElement) parent.getItemAtPosition(position);
                    Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
                    intent.putExtra("id", clickedNote.getId()); //ERROR HAS BEEN HERE!!! ID is incorrect value!
                    startActivity(intent);
                 }
            };
            listView.setOnItemClickListener(itemListener);
        }
        textCountNotes.setText(getResources().getString(R.string.count_of_notes)+noteCursor.getCount());
    }

    public void onClickButtonAdd(View view) {
        Intent intent = new Intent(this, EditorActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        db.close();
        noteCursor.close();
    }

}