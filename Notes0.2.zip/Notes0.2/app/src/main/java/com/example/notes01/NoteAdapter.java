package com.example.notes01;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class NoteAdapter extends ArrayAdapter<NoteListElement> {
    private LayoutInflater inflater;
    private int layout;
    private List<NoteListElement> noteList;

    NoteAdapter(Context context, int layout, List<NoteListElement> noteList) {
        super(context, layout, noteList);
        this.noteList = noteList;
        this.layout = layout;
        this.inflater = LayoutInflater.from(context);
    }

    public View getView(int position, View convertView, ViewGroup parent) {

        View view=inflater.inflate(this.layout, parent, false);

        TextView textHeader = (TextView) view.findViewById(R.id.textHeader);
        TextView textDescription = (TextView) view.findViewById(R.id.textDescription);
        TextView textDate = (TextView) view.findViewById(R.id.textDate);

        NoteListElement noteListElement = noteList.get(position);

        textHeader.setText(noteListElement.getHeader());
        textDescription.setText(noteListElement.getDescription());
        textDate.setText(noteListElement.getDate());
        return view;
    }
}
