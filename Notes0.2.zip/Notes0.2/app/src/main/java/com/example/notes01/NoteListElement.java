package com.example.notes01;

public class NoteListElement {
    private String header, description, date;
    private long id;

    NoteListElement( long id, String header, String description, String date) {
        this.setId(id);
        this.setHeader(header);
        this.setDescription(description);
        this.setDate(date);

    }

    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }

    public String getHeader() {
        return header;
    }
    public void setHeader(String header) {
        this.header = getShortVersion(header,20);
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = getShortVersion(description, 30);
    }

    public String getDate() {
        return date;
    }
    public void setDate(String date) {
        this.date = date;
    }

    protected String getShortVersion(String str, int length) {
        if (str.length()<length) {
            return str;
        }
        else {
            return str.substring(0, length)+"...";
        }

    }
}
