package com.example.notes01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Date;
import java.util.Locale;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

public class EditorActivity extends AppCompatActivity {
    long noteId = 0;
    SQLiteDatabase db;
    DatabaseHelper sqlHelper;
    Button buttonDelete, buttonSave;
    EditText editHeader, editDescription;
    TextView textDate;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_editor);
        textDate = (TextView) findViewById(R.id.textDate);
        editHeader = (EditText) findViewById(R.id.editHeader);
        editDescription = (EditText) findViewById(R.id.editDescription);
        buttonDelete = (Button) findViewById(R.id.buttonDelete);
        buttonSave = (Button) findViewById(R.id.buttonSave);

        sqlHelper = new DatabaseHelper(this);
        db = sqlHelper.getWritableDatabase();

        Bundle extras = getIntent().getExtras();
        if (extras!=null) {
            noteId = extras.getLong("id");
        }
        if (noteId>0) {
            Cursor noteCursor = db.rawQuery("select * from "+DatabaseHelper.TABLE+" where "+DatabaseHelper.COLUMN_ID+"=?",new String[]{Long.toString(noteId)});
            noteCursor.moveToFirst();
            editHeader.setText(noteCursor.getString(1));
            editDescription.setText(noteCursor.getString(2));
            textDate.setText(noteCursor.getString(3));
            noteCursor.close();

        }
        else {
            Date currentDate = new Date();
            DateFormat dateFormat = new SimpleDateFormat("dd.MM.yyyy", Locale.getDefault());
            textDate.setText(getResources().getString(R.string.date_is)+dateFormat.format(currentDate));
            buttonDelete.setVisibility(View.GONE);
        }
    }

    public void onClickButtonSave(View view) {
        ContentValues cv = new ContentValues();
        cv.put(DatabaseHelper.COLUMN_HEADER, editHeader.getText().toString());
        cv.put(DatabaseHelper.COLUMN_DESCRIPTION, editDescription.getText().toString());
        cv.put(DatabaseHelper.COLUMN_DATE, textDate.getText().toString());
        if (noteId>0) {
            db.update(DatabaseHelper.TABLE, cv, DatabaseHelper.COLUMN_ID+"="+noteId, null);
        }
        else {
            db.insert(DatabaseHelper.TABLE, null, cv);
        }
        goToMainActivity();
    }

    public void onClickButtonDelete(View view) {
        db.delete(DatabaseHelper.TABLE, "_id=?", new String[]{Long.toString(noteId)});
        goToMainActivity();
    }

    private void goToMainActivity() {
        db.close();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }
}