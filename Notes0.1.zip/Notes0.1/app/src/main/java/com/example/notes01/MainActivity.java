package com.example.notes01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    TextView textCountNotes;
    DatabaseHelper databaseHelper;
    SQLiteDatabase db;
    Cursor noteCursor;
    SimpleCursorAdapter noteAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        listView = (ListView) findViewById(R.id.list);
        textCountNotes = (TextView) findViewById(R.id.textCountNotes);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(), InfoActivity.class);
                intent.putExtra("id", id);
                startActivity(intent);
            }
        });
        databaseHelper = new DatabaseHelper(getApplicationContext());
    }

    @Override
    protected void onResume() {
        super.onResume();
        db = databaseHelper.getReadableDatabase();
        noteCursor = db.rawQuery("select * from "+DatabaseHelper.TABLE, null);
        String [] visibleColumns = new String[] {DatabaseHelper.COLUMN_HEADER, DatabaseHelper.COLUMN_DESCRIPTION, DatabaseHelper.COLUMN_DATE};
        noteAdapter = new SimpleCursorAdapter(this, R.layout.three_list_item, noteCursor, visibleColumns, new int[] {R.id.textHeader, R.id.textDescription, R.id.textDate}, 0);
        listView.setAdapter(noteAdapter);
        textCountNotes.setText(getResources().getString(R.string.count_of_notes)+noteCursor.getCount());
    }

    public void onClickButtonAdd(View view) {
        Intent intent = new Intent(this, EditorActivity.class);
        startActivity(intent);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        db.close();
        noteCursor.close();
    }
}