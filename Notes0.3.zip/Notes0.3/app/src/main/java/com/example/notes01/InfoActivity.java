package com.example.notes01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.text.util.Linkify;
import android.view.View;
import android.widget.TextView;

public class InfoActivity extends AppCompatActivity {
    long noteId;
    TextView textHeader, textDescription, textDate;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);
        textHeader = findViewById(R.id.textHeader);
        textDescription = findViewById(R.id.textDescription);
        textDate = findViewById(R.id.textDate);

        if(SettingsActivity.isEnableLink) {
            textDescription.setAutoLinkMask(Linkify.ALL);
        }

        Bundle extras = getIntent().getExtras();
        noteId = extras.getLong("id");

        DatabaseHelper sqlHelper = new DatabaseHelper(this);
        SQLiteDatabase db = sqlHelper.getReadableDatabase();
        Cursor noteCursor = db.rawQuery("select * from "+DatabaseHelper.TABLE+" where "+DatabaseHelper.COLUMN_ID+"=?",new String[]{Long.toString(noteId)});
        noteCursor.moveToFirst();
        textHeader.setText(noteCursor.getString(1));
        textDescription.setText(noteCursor.getString(2));
        textDate.setText(noteCursor.getString(3));
        noteCursor.close();
        db.close();
    }

    public void onClickButtonGoHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void onClickButtonEdit(View view) {
        Intent intent = new Intent(this, EditorActivity.class);
        intent.putExtra("id", noteId);
        startActivity(intent);
    }
}