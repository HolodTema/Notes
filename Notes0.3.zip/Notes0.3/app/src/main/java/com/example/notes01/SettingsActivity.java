package com.example.notes01;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;

public class SettingsActivity extends AppCompatActivity {
    static boolean isEnableLink = false;
    CheckBox checkBoxEnableLink;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        checkBoxEnableLink = (CheckBox) findViewById(R.id.checkEnableLink);
        checkBoxEnableLink.setChecked(isEnableLink);
    }

    public void onClickButtonGoHome(View view) {
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
    }

    public void onClickCheckBoxEnableLink(View view) {
        isEnableLink = checkBoxEnableLink.isChecked();
    }
}